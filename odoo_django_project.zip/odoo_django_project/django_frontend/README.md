# Django Frontend
Simple Django app that fetches Odoo data through its API.
Run:
```
pip install -r requirements.txt
python manage.py runserver
```
Visit http://127.0.0.1:8000
