import requests

ODOO_URL = "http://localhost:8069/api/sales"
ODOO_USER = "admin"
ODOO_PASSWORD = "admin"

def get_sales_orders():
    try:
        response = requests.post(ODOO_URL, json={}, auth=(ODOO_USER, ODOO_PASSWORD))
        response.raise_for_status()
        return response.json()
    except Exception as e:
        print("Error fetching from Odoo:", e)
        return []
