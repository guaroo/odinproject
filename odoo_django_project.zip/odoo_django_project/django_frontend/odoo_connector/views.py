from django.shortcuts import render
from .services.odoo_api import get_sales_orders

def home(request):
    orders = get_sales_orders()
    return render(request, "index.html", {"orders": orders})
