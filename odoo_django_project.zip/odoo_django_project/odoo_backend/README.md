# Odoo Backend
## Run
```
docker compose up
```
Visit http://localhost:8069, create a database, install **custom_sales**.
