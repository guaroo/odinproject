from odoo import models, fields

class SaleOrder(models.Model):
    _inherit = 'sale.order'
    external_sync_id = fields.Char("External Sync ID", help="Linked record ID in external system")
