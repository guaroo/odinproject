{
    'name': 'Custom Sales Enhancements',
    'version': '1.0',
    'summary': 'Adds custom REST API for sales orders',
    'depends': ['sale'],
    'data': [],
    'installable': True,
}
