from odoo import http

class CustomSalesAPI(http.Controller):
    @http.route('/api/sales', type='json', auth='user')
    def get_sales_orders(self):
        orders = http.request.env['sale.order'].sudo().search([], limit=10)
        return [{'id': o.id, 'name': o.name, 'amount_total': o.amount_total} for o in orders]
