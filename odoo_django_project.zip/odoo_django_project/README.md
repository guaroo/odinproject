# Odoo + Django Integration Demo
Run Odoo (backend) and Django (frontend) locally to learn Odoo API integrations.
